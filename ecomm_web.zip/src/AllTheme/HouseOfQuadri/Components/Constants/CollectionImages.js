export const CollectionImages = [
  {
    img: "https://houseofquadri.com/cdn/shop/files/Untitled_design_3_6a8e1c67-5910-44c6-85fe-0312f84320a3_300x.png?v=1704694624&quot",
    title: "COUPLE BANDS",
  },
  {
    img: "https://houseofquadri.com/cdn/shop/files/3_45358b25-6f53-4f60-b7ba-760d75fbf8ec_300x.png?v=1704519509&quot",
    title: "SOLITAIRE RINGS",
  },
  {
    img: "https://houseofquadri.com/cdn/shop/files/3_07202515-076e-44e5-9135-29c9d9e7c769_300x.png?v=1704694362&quot",
    title: "SOLITAIRE STUDS",
  },
  {
    img: "https://houseofquadri.com/cdn/shop/files/HOQ_Corrected_-_1_copy_300x.jpg?v=1681880180&quot",
    title: "HOQ x NATASHA",
  },
];

