export const ReadyToShipImage = [
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/ring1_4y_360x.jpg?v=1684386172",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/products/Untitleddesign_27_360x.png?v=1717480824",
    id: 131316,
    new: false,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0023_360x.jpg?v=1683524749",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/products/2_f4ec7624-53bc-4b93-a470-3cddbc8000c7_360x.png?v=1708669547",
    id: 464644,
    new: false,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0024_360x.jpg?v=1683524822",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/Almost-HOQ0510_01_retouched_jpeg_v03_360x.jpg?v=1714971251",
    id: 464646,
    new: true,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/products/ring1_1y_360x.jpg?v=1684386172",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/Almost-HOQ0671_01_retouched_jpeg_v02_360x.jpg?v=1714971339",
    id: 131346,
    new: false,
  },
];
