export const Product = [
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR07900-1YP900_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR07688-1YP900_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR06400-1YP600_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR05874-1YP600_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR05980-1RP900_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR05986-1RP600_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR00355-WGP9BT_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR03769-YGP900_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR03359-WGP600_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/R/UR00264-YG0000_11_listfront.jpg",
  },
  {
    collection: "Rings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR03349-WGP600_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05240-1CP900_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05242-1CP900_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05241-1CP9TS_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05221-1YP9TS_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05219-1YP9TS_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05199-1YP9T0_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05204-1YP900_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL05204-1YP900_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL03373-YGP6EB_11_listfront.jpg",
  },
  {
    collection: "Necklace",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL04142-1RP6P0_11_listfront.jpg",
  },
  {
    collection: "Bracelets",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/T/JT02499-1YP9TS_12_listhover.jpg",
  },
  {
    collection: "Bracelets",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/T/JT02506-1YP900_11_listfront.jpg",
  },
  {
    collection: "Bracelets",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/T/JT02509-1YP900_11_listfront.jpg",
  },
  {
    collection: "Bracelets",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/T/UT01792-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Bracelets",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/T/UT01805-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Bracelets",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/T/JT02493-1YP900_11_listfront.jpg",
  },
  {
    collection: "Diamond Elegance",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/T/JT02055-1RP900_11_listfront.jpg",
  },
  {
    collection: "Diamond Elegance",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR00594-YGP600_11_listfront.jpg",
  },
  {
    collection: "Diamond Elegance",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE05092-YGP600_11_listfront.jpg",
  },
  {
    collection: "Diamond Elegance",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL03666-1YP600_11_listfront.jpg",
  },
  {
    collection: "Diamond Elegance",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00140-YGP900_11_listfront.jpg",
  },
  {
    collection: "Diamond Elegance",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/R/JR05874-1YP600_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00734-1YP900_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00527-1YP900_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00810-1YP600_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00766-1YP600_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00126-YGP600_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00352-YGP600_11_listfront.jpg",
  },
  {
    collection: "Mangalsutra",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/S/JS00587-1YP600_11_listfront.jpg",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE09475-1RP900_11_listfront.gif",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/E/UE05121-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE09468-1RP900_11_listfront.jpg",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE09461-1PP900_11_listfront.gif",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE02852-YGP600_11_listfront.jpg",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE09477-1PP900_11_listfront.gif",
  },
  {
    collection: "Earrings",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/E/JE06163-1YP600_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/G/UG00011-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/G/UG00152-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/G/UG00010-1R0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/G/UG00219-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/G/UG00220-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/G/UG00196-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/U/B/UB00636-1Y0000_11_listfront.jpg",
  },
  {
    collection: "Others",
    img: "https://cdn.caratlane.com/media/catalog/product/cache/6/image/480x480/9df78eab33525d08d6e5fb8d27136e95/J/L/JL04783-1YP9P0_11_listfront.jpg",
  },
];
