export const TabImage = [
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/ring1_4y_360x.jpg?v=1684386172",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/products/ring1_1y_360x.jpg?v=1684386172",
    id: 131316,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0023_360x.jpg?v=1683524749",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/10_ab595554-ba0f-4b17-b01f-ea439fbf8e2e_360x.jpg?v=1701753492",
    id: 464644,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0024_360x.jpg?v=1683524822",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/products/RL0024_1_360x.jpg?v=1683524822",
    id: 464646,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/products/ring1_1y_360x.jpg?v=1684386172",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/RL0185_2_360x.jpg?v=1707460344",
    id: 131346,
  },
];

export const RelatedProductList = [
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/ring1_4y_360x.jpg?v=1684386172",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/products/ring1_1y_360x.jpg?v=1684386172",
    id: 131316,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0023_360x.jpg?v=1683524749",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/10_ab595554-ba0f-4b17-b01f-ea439fbf8e2e_360x.jpg?v=1701753492",
    id: 464644,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0024_360x.jpg?v=1683524822",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/products/RL0024_1_360x.jpg?v=1683524822",
    id: 464646,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/products/ring1_1y_360x.jpg?v=1684386172",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/RL0185_2_360x.jpg?v=1707460344",
    id: 131346,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0023_360x.jpg?v=1683524749",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/10_ab595554-ba0f-4b17-b01f-ea439fbf8e2e_360x.jpg?v=1701753492",
    id: 464644,
  },
  {
    FrontImg:
      "https://houseofquadri.com/cdn/shop/files/RL0023_360x.jpg?v=1683524749",
    BackerImg:
      "https://houseofquadri.com/cdn/shop/files/10_ab595554-ba0f-4b17-b01f-ea439fbf8e2e_360x.jpg?v=1701753492",
    id: 464644,
  },
];
