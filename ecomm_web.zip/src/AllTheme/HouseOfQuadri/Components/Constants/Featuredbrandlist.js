export const FeaturedBrandList = [
  "https://houseofquadri.com/cdn/shop/files/1200px-Grazia-Logo.svg_93a631c7-7764-4da2-bd4d-5a53f7823a9a_180x.png?v=1667031678",
  "https://houseofquadri.com/cdn/shop/files/unnamed_180x.png?v=1666181281",
  "https://houseofquadri.com/cdn/shop/files/VOGUE_logo_logotype_180x.png?v=1671178672",
  "https://houseofquadri.com/cdn/shop/files/femina_logo_image_copy_180x.png?v=1673072333",
  "https://houseofquadri.com/cdn/shop/files/logo-khush_180x.png?v=1690613304",
  "https://houseofquadri.com/cdn/shop/files/Financial-Express-Logo_180x.png?v=1666181049",
];
