export const CategoryList = [
  {
    img : "https://houseofquadri.com/cdn/shop/collections/ER0004_3_360x.jpg?v=1704703114", 
    name : 'Earrings'
  } ,
  {
    img : "https://houseofquadri.com/cdn/shop/collections/ER0001_2_360x.jpg?v=1704703166" ,
    name : "NeckLace"
  },
 {
  img :  "https://houseofquadri.com/cdn/shop/collections/RL0002_3_360x.jpg?v=1704703186" ,
  name : "Rings"
 },
  {
    img : "https://houseofquadri.com/cdn/shop/collections/BR_360x.jpg?v=1704703141" ,
    name : "Bracelets"
  },
];

export const diamondShapes = [
  {
    shape: "Round",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Round_8799c972-1c9a-456e-8928-d838891dc0c2.png?v=1703580835",
  },
  {
    shape: "Oval",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Oval.webp?v=1703580834",
  },
  {
    shape: "Emerald",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Emerald.png?v=1703580834",
  },
  {
    shape: "Princess",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Princess-Cut.png?v=1703833677",
  },
  {
    shape: "Cushion",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Cushioin.png?v=1703580835",
  },
  {
    shape: "Pear",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Pear.png?v=1703580835",
  },
  {
    shape: "Radiant",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Radiant.png?v=1703580835",
  },
  {
    shape: "Marquise",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Marquise.png?v=1703580835",
  },
  {
    shape: "Heart",
    img: "https://cdn.shopify.com/s/files/1/0643/8731/8014/files/Heart.png?v=1703580835",
  },
];