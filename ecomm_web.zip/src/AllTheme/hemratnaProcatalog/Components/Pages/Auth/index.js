import React from 'react'

const index = () => {
  return (
    <div>Auth</div>
  )
}

export default index