import React from 'react'
import TopBanner from './TopBanner/TopBanner'
import ProAlbum from './ProAlbum/ProAlbum'
import AlbumLists from './AlbumLists/AlbumLists'

const Index = () => {
  return (
    <>
    <TopBanner />
    <AlbumLists />
    </>
  )
}

export default Index