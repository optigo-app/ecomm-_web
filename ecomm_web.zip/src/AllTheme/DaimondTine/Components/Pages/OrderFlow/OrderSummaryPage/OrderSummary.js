import React from 'react'

const OrderSummary = () => {
  return (
    <div>OrderSummary</div>
  )
}

export default OrderSummary