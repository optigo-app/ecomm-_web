import React from 'react'

const Auth = () => {
  return (
    <div           aria-label="Dummy Auth Page"
>Auth</div>
  )
}

export default Auth