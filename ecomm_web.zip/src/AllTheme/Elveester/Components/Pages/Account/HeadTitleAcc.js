import React from 'react'
import "../Account/HeadTitleAcc.scss"
const HeadTitleAcc = ({title}) => {
  return (
    <div className='title_Account_Elvee'><div className='HeadTitleAcc_elvee'>{title}</div></div>
  )
}

export default HeadTitleAcc