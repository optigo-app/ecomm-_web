import "./Topbar.for.scss"
import React from 'react'

const TopBar = () => {
  return (
    <div className="for_topbar"><span>Shop Lab Grown Diamond Jewelry 💎💍</span></div>
  )
}

export default TopBar