import React from 'react'
import Drawer from './Drawer'




const Cart = () => {
  return (
    <div>
        <Drawer/>
    </div>
  )
}

export default Cart